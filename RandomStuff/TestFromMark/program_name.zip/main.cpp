#include <iostream>
#include <iomanip>

using namespace std;
int main(){
cout << (1/3) << endl;
}