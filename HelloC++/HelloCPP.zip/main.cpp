#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    cout << fixed << setprecision(2);
    cout << "Hello C++! yayayay i love github" << endl;
    cout << (1/3.0) << endl;
    return 0;
}