double fallingDistance(double userDouble){
    double g =9.8;
double d = ((.5)*g)*(userDouble*userDouble);
return d;
}