#ifndef FUNCTIONS_H
#define FUNCTIONS_H


double fallingDistance(double userDouble);

#endif