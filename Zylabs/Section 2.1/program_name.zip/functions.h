#ifndef FUNCTIONS_H
#define FUNCTIONS_H

double nextFreq(double f);

#endif
