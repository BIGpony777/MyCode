#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string>
using namespace std;

string removeSpaces(string userString);

#endif