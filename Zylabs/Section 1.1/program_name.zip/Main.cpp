#include <iostream>
using namespace std;

int main() {

   cout << "  NO PARKING" << endl;
   cout << "1:00 - 5:00 a.m." << endl;

   return 0;
}