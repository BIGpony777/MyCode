#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void removeGray(int redAmount, int greenAmount, int blueAmount, int result[]);

#endif